import React, { useState, useEffect, useRef } from 'react';
import { Loader2 } from "lucide-react";

interface Transcript {
  id: string;
  speaker: string;
  time: string;
  text: string;
  isSelf: boolean;
}

const fakeTranscripts: Omit<Transcript, 'id' | 'isSelf'>[] = [
  { speaker: "张伟", time: "10:45:23", text: "好的，下周三定方案。" },
  { speaker: "李芳", time: "10:45:45", text: "我同意，资源再倾斜10%。" },
  { speaker: "我", time: "10:46:00", text: "没问题，我来跟进。" },
];

export function TranscriptsArea() {
  const [transcripts, setTranscripts] = useState<Transcript[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      if (index < fakeTranscripts.length) {
        const item = fakeTranscripts[index];
        setTranscripts(prev => [...prev, {
          ...item,
          id: Date.now().toString(),
          isSelf: item.speaker === "我"
        }]);
        index++;
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [transcripts]);

  return (
    <div className="flex flex-col h-full bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
      <div className="p-3 border-b border-slate-800 flex justify-between items-center bg-slate-900">
        <h3 className="text-sm font-bold text-slate-200">实时转写</h3>
        <div className="flex items-center gap-1 text-xs text-emerald-500">
          <span className="flex gap-0.5">
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce" />
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce delay-150" />
            <span className="w-1 h-1 bg-emerald-500 rounded-full animate-bounce delay-300" />
          </span>
          转写中...
        </div>
      </div>
      
      <div className="flex-1 p-4 overflow-y-auto space-y-4" ref={scrollRef}>
        {transcripts.map((t) => (
          <div key={t.id} className={`flex flex-col ${t.isSelf ? 'items-end' : 'items-start'}`}>
            <div className="flex items-center gap-2 mb-1 px-1">
              <span className="text-xs font-bold text-slate-400">{t.speaker}</span>
              <span className="text-[10px] text-slate-600">{t.time}</span>
            </div>
            <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
              t.isSelf 
                ? 'bg-blue-600 text-white rounded-tr-none' 
                : 'bg-slate-800 text-slate-200 rounded-tl-none'
            }`}>
              {t.text}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
